# Android 1.4.29 三端共用手机私钥（本机候选）

版本 `1.4.29` / `versionCode 44` 将阿里云、甲骨文 1 和甲骨文 2 的 SSH 身份统一到一份手机加密私钥。设置页的“全服务器共用 SSH 私钥”只需导入一次，三个服务器档案仍分别保存地址、用户名、端口和主机指纹。已有阿里云私钥可以直接点“沿用阿里云当前私钥作为共用私钥”。

已有每档案密文和默认服务器密文保留作兼容回退。导入连接文件也会把其中的私钥存为共用私钥。应用不会替用户修改服务器授权，需把同一公钥分别登记到三台服务器对应的受限 SSH 账号。当前候选已完成本机 Debug assemble、Lint 和 JVM 单元测试，服务器公钥登记、APK 发布和真机交互待完成。

# Android 1.4.28 服务器控制台布局优化

[GitHub Release v1.4.28](https://github.com/dhy824/dhy-server-console/releases/tag/v1.4.28) 提供原签名 APK、校验清单和许可证。覆盖安装保留已有档案。需要回退时使用原签名、更高 versionCode 的恢复包。

总览与设置继续使用蓝白圆角卡片。手机窄屏以单列排列，平板、横屏和宽窗口按实际可用空间展开双列。系统字体放大时优先堆叠按钮并保留完整文字。主导航随窗口宽度在底栏和侧栏间切换，短横屏侧栏可滚动。

「设置」上方直接显示当前服务器和「导入服务器连接文件」。其他服务器卡片可一键切换，编辑、单独导入私钥、生成密钥与移除等操作在「管理档案」里。1.4.27 签发的甲骨文连接文件可以继续使用。升级保留现有档案和登录资料。

# Android 1.4.27 服务器连接文件

在「设置 → 其他服务器」点「导入服务器连接文件」，选择维护端发放的甲骨文 1 或甲骨文 2 文件。客户端从文件读取 SSH 地址、端口、专用用户名和主机公钥，在严格核对主机公钥后用文件内的私钥认证。验证通过后加密保存密钥，自动选中档案并回到总览。重复导入相同连接会更新对应档案。甲骨文 1 提供 CPA 管理页，甲骨文 2 提供 SearXNG 搜索与实例配置。页面内部的登录口令按原流程使用。

已有 SSH 私钥仍可在具体服务器档案内用原导入入口导入。新版连接文件包含私钥，应通过可信渠道在自己的设备间传输。若提示连接校验失败，先检查网络和文件归属，向维护端核对服务器状态。升级沿用原签名；回退需要原签名、更高 versionCode 的恢复包。

# Android 1.4.26 SearXNG 实例配置

[GitHub Release v1.4.26](https://github.com/dhy824/dhy-server-console/releases/tag/v1.4.26) 提供原签名升级 APK、校验清单和许可证。

「总览 → 编辑实例配置」通过所选 SearXNG SSH 档案固定转发到服务器的 127.0.0.1:18889。搜索网页、偏好和引擎状态使用原转发目标。使用该入口需部署相应的回环配置编辑服务，服务器账号须允许该转发目标。原签名升级保留旧档案，回退包使用原签名和更高 versionCode。

# 2026-11-20 Android SearXNG 页面快捷入口 1.4.25

本地候选 1.4.25（versionCode 40）在“总览”的 SearXNG 卡片新增“偏好设置”和“引擎状态”，沿用所选档案的 SSH 转发与主机校验。三个入口分别打开首页、/preferences、/stats。偏好设置按浏览器保存，实例默认引擎、搜索格式和上游参数由服务端 settings.yml 管理。SSH 连接和排障步骤见《使用说明》。

# 2026-11-20 Android SearXNG 网页 1.4.24

[GitHub Release v1.4.24](https://github.com/dhy824/dhy-server-console/releases/tag/v1.4.24) 提供原签名 APK、校验摘要和许可证。

在“设置 → 其他服务器”点加号，选择 SearXNG 并添加第二台甲骨文的 SSH 档案。手机为该档案单独保存加密私钥与固定主机指纹。选中档案后，从“总览 → 打开 SearXNG 网页”经隔离的本机回环地址转发到所选服务器的 `127.0.0.1:18888`。偏好设置页返回 HTTP 200 后打开首页，可在应用内搜索、查看偏好设置和引擎状态。点击结果链接由系统浏览器打开。

生成手机密钥后，请管理员为该公钥单独授权 SSH 回环转发目标 `127.0.0.1:18888`。连接测试时通过可信来源核对主机指纹。连接失败先检查所选档案、手机公钥授权和服务器转发白名单。Public 构建使用空默认地址，沿用原应用签名。旧版覆盖安装和回退步骤见“验证与回退”。

# 2026-11-19 Android CPA 管理页转发 1.4.23

甲骨文 CPA 入口按老 ECS 的方式通过所选服务器档案里的 SSH 私钥建立本机回环隧道，再打开 CLIProxyAPI 自带管理页 `/management.html`，目标为服务器回环 `127.0.0.1:8317`，页面返回 HTTP 200 后才打开。管理页登录使用 CLIProxyAPI 的 Management Secret；Android 不改写服务端凭据或阿里云 SSH 私钥。2026-11-19，Oracle `ap-osaka-1` 已启用原生管理页并通过电脑端 SSH 隧道验收，`allow-remote: false` 保持不变。手机真机交互仍待验证。

# 2026-11-18 Android 全局服务器选择 1.4.22（已发布）

版本 `1.4.22` / `versionCode 37` 将设置中的“阿里云 / 甲骨文”选择作为全 app 活动服务器。阿里云沿用已有连接与私钥；甲骨文档案独立保存 SSH 私钥、主机指纹和 CPA 配置。选择甲骨文时目前只显示 CPA 控制台；API、AstrBot、Zako、订阅、测速、审核和更新入口先隐藏，待相应服务器能力配置后再增加。终端当前也仅用于阿里云。

切换目标会停止既有隧道。CPA、SSH 隧道、主机指纹测试、终端、订阅、审核与更新请求均读取活动服务器快照；密钥按活动档案单独读取，并在连接请求后清零。GitHub Release `v1.4.22` 已由 Actions `44319761428` 发布，提交 `d4ba7e66bdb8c2630edbaba6332470d4b2856f97`。Release/Lint/43 项 JVM 测试、Public 空默认地址和与 `v1.4.21` 的签名连续性通过；APK SHA-256 为 `e6c86982166f0be34559a3adcc3ed79df8879c4c93d8b4f34d5e501de18cdfeb`。Release Lint 有 4 条 AndroidX 依赖更新提示，本版未升级依赖。真机交互尚未验收；未更改服务器、DNS 或公网入口。

# 2026-11-18 Android CPA SSH 密钥生成 1.4.21

源码版本1.4.21/versionCode36在每个 CPA 档案中新增手机端 Ed25519 密钥生成。私钥在本机生成后立即加密保存，不导出、不传输；应用仅显示/复制公钥及 SHA-256 指纹。新公钥需按服务器管理员的授权流程登记到所选 CPA 服务器后，SSH 登录才会通过。遵循既有 ECS 设备接入的“每设备独立密钥、只提交公钥、管理员审批、精确回退”原则；ECS 固定 MCP 网关不替代 Oracle 服务器 SSH 授权，也不由本功能修改远端 `authorized_keys`。

旧版安卓端通过导入 `.key` 私钥进行 SSH 认证。1.4.21 仍使用私钥认证，只是改为在手机内生成并加密保存，不再要求用户从外部取得私钥文件；向服务器管理员提供的是配对公钥。

本版通过 Release、Lint、40 项 JVM 测试、APK Public 默认地址和原签名连续性检查。APK SHA-256 为 `79dc1c4b93df275a1c506f7051be4a647bb845b47706a72ee72d924ace227529`。真机 SSH 连接与页面交互尚未验收；应用不会代替管理员登记公钥，也不会修改服务器 `authorized_keys`。

# 2026-11-18 Android CPA 独立服务器选择器 1.4.20

源码版本1.4.20/versionCode35已正式发布为[GitHub Release v1.4.20](https://github.com/dhy824/dhy-server-console/releases/tag/v1.4.20)。新增独立 CPA 服务器档案选择器，每个档案使用单独加密的 SSH 私钥、独立固定的主机指纹和不可复用的本机回环来源；只转发所选服务器的回环 8317，固定插件路径返回 HTTP 200 后才打开。默认 SSH 连接、服务器配置、DNS 和公网入口保持不变。GitHub Actions `44236871591` 成功，Release、Lint、36项JVM测试、空默认地址与原签名连续性通过；APK SHA-256 为 `70b49ba79177b0118388de61df0a48d218b0abf4999778a051bd96da4630228f`。Android 真机和目标服务器连接仍待用户验收。

# 2026-11-12 Zako 动态本地转发修复与首页审核入口 1.4.17（已正式发布）

# 2026-10-22 审核中心自动刷新适配 1.4.7（已正式发布）

当前维护源码1.4.7/versionCode22。该版本曾把审核入口放在首页并自动刷新服务器批次；2026-11-12的1.4.13重新调整为首页只显示“打开审核中心”按钮，不显示审核批次条目。

Public Release `v1.4.7` 已由 GitHub Actions 39712589464 正式发布：[下载 v1.4.7](https://github.com/dhy824/dhy-server-console/releases/tag/v1.4.7)。APK SHA-256 为 `15c1e3ace5e081102959604066989707559cf18110b3b2d3acee058cc8f64c7d`；当前无连接手机，真机安装和网络交互仍待验证。

原签名、包名、连接/私钥/主机信任/WebView登录保持，Public默认空host。Release/Lint/JVM/Public与原签名构建通过；真实桥接iframe触摸/保存下一题通过，已由Actions39016259953正式发行，[下载v1.4.6](https://github.com/dhy824/dhy-server-console/releases/tag/v1.4.6)；标签de052ca6与实际下载四附件SHA256核对通过。手机真机安装与网络交互仍待验。更新包可沿原签名覆盖安装，不卸载、不清数据。服务器回退软件保留最新评分/业务库；Android回退用原签名更高versionCode并保留新旧密文读取。

# 2026-10-17 通用审核中心 1.4.5

当前维护源码1.4.5/versionCode20。新增“审核”页，显示服务器批次、已审/待审和最近保存时间；经现有SSH通道在应用内打开插件审核中心，手机和电脑共用保存记录。评分支持备注、标签及可选分数，多端冲突会提示处理；审核只记录意见，不直接应用人格或执行运维。

沿原包名、原签名和Keystore读写方式，保留用户连接、密钥、主机信任和WebView登录。Public构建默认空host；不内嵌题目、评分或凭据。唯一源码仍是本目录，公开导出沿export-public-source.py；服务器数据/实现不进入公开APK源码。版本回退用原签名更高versionCode并保留新旧密文读取能力，不卸载清数据。构建/Lint/JVM/签名已过，已由Actions39009697514正式发布v1.4.5；标签2168a62fd2a713604729a6d8124587c0479148f4及实际下载四附件逐项核对通过。APK SHA256为fb2d36119751273e65d5b40490cf2c8891cdecc934a716afd9fbb45b5f15b474，手机真机交互仍待验证。

# 2026-10-14 本机 Keystore 恢复修复 1.4.4

当前维护版本1.4.4/versionCode19，沿原签名覆盖安装；已通过GitHub Actions38496112672正式发布，实际下载四附件与标签绑定均核验通过；APK SHA256为837db6905ead152e4667d4ba03825c0650c09685d1ef472bb6af82678874117e。正式发行入口为 https://github.com/dhy824/dhy-server-console/releases/tag/v1.4.4 。本次修复截图中的KeyStoreException：读取旧密文时只查已有Android Keystore密钥，不再因密钥缺失生成错误的新密钥；本机密钥读取错误与SSH认证、主机校验错误分别提示。系统明确允许即时重试的临时故障最多重试三次；永久失效提示重新导入，不循环建通道。

若更新后仍提示密钥失效或无法使用，先解锁或重启手机再试；仍失败时打开“设置 → 更换私钥”，选择原来连接服务器的SSH私钥文件（不是.pub公钥）。重新导入用新的应用专属AES密钥，先实际加解密验证，再原子保存，并保留旧加密备份和原AES别名。无需清除应用数据、更换服务器SSH密钥或重新填写所有设置。旧系统AES密钥确实丢失时，更新无法从密文恢复私钥，必须有原SSH私钥文件；若手机Keystore服务仍无法创建或使用新密钥，应用会明确失败并保留原数据，不改用明文存储。PlayIntegrityFix是否导致此次故障尚未证实，本应用不会更改它或系统设置。

Release、Lint、26项JVM测试及APK空host/非调试/原签名连续性通过。新增11项实际AES/GCM测试覆盖旧格式、缺失密钥、临时/永久故障、显式重新导入、坏密文与提交异常；JVM测试不代表小米14 Ultra/Android16硬件Keystore或手机网络已验收。手机/平板布局、Cookie和服务器严格主机校验保持既有方式。

旧v1.4.3正式发行及签名保留；原加密备份位于应用私有ssh_identity.previous.enc，仅显式更换私钥时产生，不上传。回退不卸载、不清数据；Android通常不能直接覆盖较低versionCode，应沿原签名构建更高versionCode的回退包，并保留本版新旧密文读取能力，不能用旧版读不懂的新格式覆盖恢复。发布与下载核验回执见维护工作区output/keystore-version-repair-20261014；未获得成功回执前不能称GitHub发布完成。

# 2026-10-14 隧道健康与错误提示 1.4.3（已正式发布）

当前源码和原签名正式包为1.4.3/versionCode18，已通过GitHub Actions38436101635正式发布：[APK与附件](https://github.com/dhy824/dhy-server-console/releases/tag/v1.4.3)。实际下载的APK/许可证附件逐字节一致，校验清单和JSON按内容核验一致。旧1.4.2保留。已有通道在复用前和五秒状态检查中探测固定回环页面；页面不响应时不再显示运行中，用户再次打开时仅重建一次，并恢复原已打开的两个转发。新通道通过页面检查才显示成功。关闭/网络失败不进行无界自动重连，保持现有密钥和严格主机校验。

错误提示包含失败阶段以及安全的异常类型，区分认证、主机密钥、超时、DNS、连接拒绝和端口占用；不展示原始库错误中的地址、用户名或密钥路径。SSH连接失败时清理未返回的会话。内置页面等待预算35秒，覆盖一次重连与有界页面检查。HTTP检查只访问127.0.0.1根路径，不跟随重定向、不读正文、不携带登录信息、不走系统代理；200/401/302视为可达，超时或5xx失败。

Release/Lint和15项JVM测试通过，公开空host/非调试/原签名连续性通过。同版本JSch与相同移动端KEX/cipher在本机连接当前服务器，两个转发均HTTP200；这仅证明本机网络下兼容，手机网络、安装与错误是否消失尚未验证。APK见output/tunnel-repair-20261014/服务器控制台1.4.3-candidate.apk。手机和平板布局、Cookie和设置存储保持既有方式。

本批已取得用户发布确认。旧正式v1.4.2及签名保留；回退保留旧APK和源码，不清除应用数据、不换签名。Android通常不允许低versionCode直接覆盖，真机若需回退应由维护端用旧源码构建更高versionCode并沿原签名发布，不建议卸载清数据。本批沿唯一手册及context_sync原生全文验收收尾。

# 1.4.2 蒸馏进度入口（已发布）

版本1.4.2/versionCode17：总览新增“查看蒸馏进度”，复用已有AstrBot SSH隧道、应用内WebView和系统浏览器，登录后直达Null/仔仔同一个蒸馏中心。服务器1.28.0提供双人看板；不在手机运行分析或保存聊天记录。已有SSH配置、密钥和登录状态沿原应用保留；使用原签名连续构建，旧v1.4.1发行保留。应用不创建分析任务或应用Persona；手机实际覆盖安装与交互仍待真机验收。

# Android 服务器控制台

源码版本 1.4.28（versionCode 43）。Jetpack Compose + SSH，设置中的阿里云 / 甲骨文选择决定所有显示功能的当前 SSH 目标。甲骨文 CPA 入口使用 CLIProxyAPI 自带的 `/management.html`，经 SSH 本机回环转发，不走 FreeTier2API 插件路由。

## CPA 服务器档案

在“设置 → 服务器”中选择甲骨文档案，为该档案生成或导入独立 SSH 私钥；私钥只保存在本机加密存储。新公钥需先由服务器管理员登记，再核对主机指纹。选择甲骨文后在“总览”打开 CPA 管理控制台。与老 ECS 一样，Android 使用所选档案的 SSH 私钥认证并仅转发到该服务器的 `127.0.0.1:8317`，再打开 `/management.html`；页面返回 HTTP 200 后才打开。网页登录使用服务端 CLIProxyAPI 配置的 Management Secret。服务端须启用控制面板并配置 Secret，`allow-remote: false` 时只通过回环入口访问管理页。

每个档案的私钥以 Android Keystore 单独加密；删除档案不会影响阿里云原私钥。地址/端口修改会清除该档案的主机指纹和密钥，必须重新授权和核对。不同档案使用不同的 `127.0.0.x` 回环来源隔离 WebView Cookie，已退役来源不复用。管理密码为服务端 CLIProxyAPI 配置的 Management Secret，不由 Android 保存或改写。

1.4.24 正式签名包沿用原包名与原签名，保留 Android Keystore 旧密文读取和已有私钥导入方式。Release、Lint、45 项 JVM 测试、Public 空默认地址及与 1.4.23 的签名连续性均通过。电脑端经 SSH 验证 SearXNG 首页、偏好设置和引擎状态页均为 HTTP 200，实际 JSON 搜索返回 40 条。手机公钥登记与真机交互待验。本地 Debug 包使用测试签名。回退须以原签名和更高 versionCode 构建恢复包，并保留档案及密文读取兼容，不卸载清数据。

1.4.20 已由 GitHub Actions 运行 `44236871591` 正式发布；Release、Lint、36 项 JVM 测试、Public 空地址、非调试标记及原签名连续性均通过。APK SHA-256 为 `70b49ba79177b0118388de61df0a48d218b0abf4999778a051bd96da4630228f`。Android 真机安装与目标服务器交互仍待验证。设备回退须沿原签名构建更高 versionCode 的恢复包，不卸载清数据。

1.4.1 已于 2026-10-08 经用户确认发布：[正式 APK 与附件](https://github.com/dhy824/dhy-server-console/releases/tag/v1.4.1)。Actions 37704959564 成功，实际下载 APK 摘要与本地一致。更新页复用首页的磨砂白卡、蓝色图标、22dp 圆角与间距；版本并排展示，窄屏改为纵排，说明与任务编号按需展开。查询原任务可显示下载阶段、已下载 MiB 与具体失败原因；不显示未经核验的完成百分比，也不将下载失败误称回退成功。

## 唯一源码与目录

本目录是唯一编辑源；opensource/amadeus-android-server-console 由 export-public-source.py 白名单导出，不能两处手工改。opensource/amadeus-console-release-123 是冻结的 1.2.3 历史快照。1.4.2已正式发布：[APK与附件](https://github.com/dhy824/dhy-server-console/releases/tag/v1.4.2)，本批已验证手机393dp、320dp/1.5倍字体和800dp平板实际Compose布局；Release/Lint/12项JVM及空host/非调试/签名连续性通过。真机安装与连接交互未测。此前 1.4.0 已于 2026-10-06 通过 GitHub Actions 发布：[正式 APK 与附件](https://github.com/dhy824/dhy-server-console/releases/tag/v1.4.0)。旧 v1.3.0 保留。真机安装及交互仍待验收。

| 入口 | 职责 |
| --- | --- |
| data/AppConfig.kt | 配置存储；每次 current 重新读取，Service/VM 不持有过期配置 |
| data/SecureKeyStore.kt | 私钥安全存储、有界读取、密文修订指纹 |
| ssh/ConnectionIdentity.kt | 主机、端口、用户名、信任与私钥版本决定复用 |
| ssh/BoundedOutput.kt / SshEngine.kt | 有界输出、单调时钟超时、取消与超限失败 |
| service/TunnelService.kt | 单线程连接管理、请求回执、五秒存活/配置检查 |
| updates/UpdateProtocol.kt / UpdatesViewModel.kt / ui/UpdatesScreen.kt | 项目版本、逐项升级确认、原任务回执恢复 |
| AppViewModel.kt | 用户动作与请求回执关联；更改设置时停止旧连接 |
| Test-Apk.ps1 | APK 本体包名/版本/公开默认值/签名验收 |
| Build-State.ps1 | 构建/发布共用互斥、配置与环境恢复、临时目录及盘符归属校验 |
| tests/Test-Build-State.ps1 | 合成目录中的构建失败、空文件、并发与清理回归；无需手机或签名 |

隧道关闭后不会残留“运行中”状态；断开后提示重新打开，不做无界重连。持续输出不会不断积累内存；订阅 JSON 超限报错，不返回截断内容伪装成成功。修改连接相关代码，应连同 app/src/test 中的契约测试维护。

## 项目更新（1.4.1）

“更新”页提供 Mihomo、Nginx、CLIProxyAPI、Zako、AstrBot 的已安装版本、GitHub 版本与发布说明。先在“设置”导入管理员 SSH 私钥并核对主机指纹，再点“检查所有项目”。来源固定为 MetaCubeX/mihomo、nginx/nginx、router-for-me/CLIProxyAPI、mizaawa/ZakoProxyCLI、AstrBotDevs/AstrBot；GitHub 由服务器访问，失败显示未核验，可打开官方发布页，不沿用旧检查结果。

服务器前提是已由维护端审阅安装 `/usr/local/lib/server-toolbox/project_updates.py`，客户端固定执行 `/usr/bin/python3 -B /usr/local/lib/server-toolbox/project_updates.py`，通过标准输入发送 JSON。此应用不自动安装服务器组件；组件不可用时检查/准备失败。服务端策略唯一源码位于运维工作区 `个人服务器工具箱/server/project_updates.py`，手机仅实现既有 release、inspect、plan、execute、result 契约。`assets/update_probe.py` 是工具箱同名只读探针的发行快照；更新探针时从唯一源同步并核验一致，不在手机另写升级策略。

Mihomo、Nginx、CLIProxyAPI、Zako 按 inspect → plan → 用户确认 → execute → result 执行；确认对话框列明实际版本、影响、备份编号和回退方式。计划限时 5 分钟，绑定连接、固定主机密钥及私钥修订；服务器重新核对程序、配置、服务和目标版本。确认只消费一次，提交前将任务编号、计划摘要和连接指纹原子写入应用私有 no-backup 目录。退出/断网不会自动重发或取消服务器任务；重开应用恢复编号，点“查询上次升级结果”。没有批量升级或自动更新。

- Mihomo：官方包摘要、候选配置、备份、代理与控制器健康检查，失败尝试恢复旧程序。
- Nginx：GitHub 最近 100 个标签仅作参考，可能含 mainline；安装走原 APT 源和当前索引，不刷新索引，不切软件源，先保存原版本包与配置，再安装并做 nginx/HTTP 验收，失败尝试恢复。
- CLIProxyAPI：同主版本升级才允许准备计划，跨主版本需单独兼容性评审；只替换程序，OAuth 数据原位保留。
- AstrBot：仅检查；带 beta 等标记的版本明确显示预览，核心升级继续走既有维护流程。

结果为 queued/running/not_found/needs_attention 或响应不可核验时，阻止新升级，继续查询同一编号。not_found 不证明请求从未到达：联系维护端核对原编号及服务状态，不清应用数据绕过门禁。回执损坏或连接不符也拒绝新提交；恢复原连接/原回执后再查。回执只保存标识，不保存私钥、配置正文或完整计划。更换手机不会迁移 no-backup 回执，必须先在原设备或维护端核对未完成任务。

服务器 helper 1.0.1 提供阶段、下载字节与生产修改标记：大包 60 秒读取、900 秒总预算，网络失败最多回退已有 Mihomo 回环代理一次，仍校验官方 HTTPS 来源、大小与 SHA-256。Android 不另写下载策略或安装 helper。1.4.1 只在回执明确为 production_change_started=false 时说明服务器程序未改动；未知状态继续查询，矛盾回执不解锁新升级。旧 helper 没有这些字段时显示已有状态，不推断已回退。CLIProxyAPI 跨主版本在版本卡上直接提示需兼容性评审；AstrBot 保持仅查看。

## 本机构建

需要 .toolchain 中的 SDK 35、JDK 17、Gradle 8.11.1；现有工具链可直接复用，缺少时先阅读 prepare-toolchain.ps1。本目录执行：

~~~powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File build-debug.ps1 -Mode Public
powershell.exe -NoProfile -ExecutionPolicy Bypass -File build-release.ps1 -Mode Public
~~~

脚本执行 assemble、lint 和 testDebugUnitTest，随后核验 APK 本体。中文路径通过临时 subst 盘构建，aapt 验收用临时 ASCII 路径。Public 是默认模式，构建前明确写入空 host，不读取本机个人连接设置。Personal 显式读取桌面配置，生成的个人 APK 不得公开分享。构建结束恢复原 default-config.properties。

构建与发行打包使用同一源码目录互斥锁，另一个进程并发执行会明确失败。成功或异常退出都恢复 default-config.properties、local.properties 的原始字节及 JAVA_HOME/ANDROID_SDK_ROOT/ANDROID_HOME；原先不存在的临时配置会移除，空文件仍保持为空。只移除本次成功创建且仍指向同一项目的 subst 盘；盘符被改指向时拒绝清理，并报告待处理项。系统强杀或断电无法保证 finally 执行，恢复后先检查这些项。

盘符归属使用 Unicode Win32 API 核验，避免中文路径被本地化命令输出误解码。Gradle 合并接收标准输出和错误输出，并以退出码判定构建成败；警告不会被 PowerShell 5 当作脚本异常提前终止，非零退出仍失败。

只验证构建脚本契约，无需运行 Gradle：

~~~powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tests/Test-Build-State.ps1
~~~

更改 Build-State 时需连同根 release-public-apk.ps1、Test-Apk.ps1 和白名单导出检查。回滚这组脚本须保持同一版本，不能只移除共享 helper。

Release 只能使用已有 .signing 中的一对签名文件。缺少任一个立即失败，**不会自动生成新签名**。恢复时从用户已有备份找回原文件；不得为“修构建”换钥。验收与工作区 release-public/v1.2.3 原正式包比较签名连续性。公开贡献者无签名时只构建 Debug，不能冒充正式发布。

## 公开源码与本地正式产物

工作区根目录执行：

~~~powershell
python -X utf8 Amadeus安卓端/export-public-source.py
python -X utf8 Amadeus安卓端/export-public-source.py --check
powershell.exe -NoProfile -ExecutionPolicy Bypass -File release-public-apk.ps1
~~~

已有刚构建的 Release 可用 -UseExistingBuild，但仍必须通过 APK 本体验收。公开发布写入新的 release-public/v版本/，包含 APK、SHA256SUMS、验收 JSON 和许可证。既有版本目录拒绝覆盖；没有自动上传。源码导出仅复制登记的代码/资源/许可证/说明，不带 .signing、toolchain、默认个人配置、local.properties 或生成产物，修改前副本保存在 output/source-export-backups。

验收读取 APK 中的所有 default_host 值，而非旁边生成的 XML；校验签名、包名、版本和非调试标志通过后才晋升正式目录。构建输入与验收结果应随该次实施报告留档。

### GitHub 发行

历史 GitHub 公开版本1.4.2 / versionCode17于2026-10-13经用户明确授权发布，Actions38421804663及实际APK/附件下载摘要通过。白名单源码与release-public/v1.4.2已验收产物复制到公开仓库dist，codex/android-updates-v1.4.2触发publish-release-v1.4.2.yml；发布提交7a22395ccf925d65002d804c1964c79a878db34b，APK SHA-256为9db1a5c73fce2438e238a9b36b31c2f83b0f0091e0b2314e602f4867ab27f247。原v1.4.1保留。已有同名 Release 时拒绝覆盖，失败先检查草稿和运行记录，不强推、不替换已公开附件。源码/签名备份与旧 v1.4.0 保留。推送前仍按工作区要求确认本次具体公开内容。

本地构建与导出不代表已发布。发布后需检查 Actions、标签指向和下载 APK 的 SHA-256。撤下新 Release 不能把已安装设备降级；设备恢复旧功能建议用原签名构建更高 versionCode 的回退包，避免卸载清数据。

## 验证范围与回滚

1.4.1 Public Release、Lint 与 12 项 JVM 契约测试通过，APK 空 host、非调试与原签名连续性核验通过。新增覆盖下载进度、修改标记缺失/矛盾、未知阶段及 CLIProxyAPI 跨主版本提示。隔离预览使用实际 Compose 页面源码，实验截图工具不进入正式依赖或公开源码；393dp 手机、320dp/1.5倍字体、700dp 平板与下载中状态四份实际 Compose 预览已生成并检查，未见挤压或遮挡。真机覆盖安装、后台回收、网络切换与连接交互仍待实测。

1.4.0 已完成 Public Release 构建、Lint、9 项 JVM 契约测试、APK 空 host 与旧签名连续性检查。测试覆盖数字版本、预览标识、计划项目/时效/连接绑定、未知或不匹配回执不得解锁新升级。GitHub Actions 37488403331 成功，公开附件 SHA-256 与本地正式包一致。尚无真机安装、系统杀后台、网络切换、服务器连接交互的实测，不将单测当作这些场景的证明。

2026-09-30 构建事务补验：8 项合成状态回归通过，覆盖成功/失败恢复、空文件、中文路径盘符、外来映射、嵌套锁、跨进程并发与目录清理边界。中文工作区内 Public Debug 实际构建通过，构建前后两个配置文件及三个环境变量一致；已有 1.3.0 正式发行目录保留。

源码回滚使用同次备份（本次运维工作区 output/android-updates-20261008/source-backup，公开导出另有逐文件备份）；设备回滚 Android 通常不能覆盖安装低 versionCode，优先以原签名制作更高 versionCode 的回退构建。不要为降级卸载或清除数据。本工具不会自动卸载、清数据或更换签名。旧 APK 与签名备份必须保留。

## 依赖与隐私

自身 MIT；Compose/AndroidX/Haze 为 Apache 2.0，JSch 为 BSD 3-Clause，Bouncy Castle 为 MIT，详见 LICENSE/licenses 与各发行包。项目由 AI 辅助维护并接受人工审核。

不新增公网管理端口；不公开真实服务器地址、用户名、私钥路径、订阅凭据与日志。构建日志仅在本机留存，分享前脱敏。
